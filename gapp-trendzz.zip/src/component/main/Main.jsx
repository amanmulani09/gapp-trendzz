import React from 'react'
import Header from '../header/Header'

const main = () => {
  return (
    <div>
      <Header />
    </div>
  )
}

export default main