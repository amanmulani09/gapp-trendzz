import Main from './main/Main'
import Login from '../login/Login';
import Signup from '../signup/Signup';
import Product from './product/Product';

export {
    Main,
    Login,
    Signup,
    Product
}