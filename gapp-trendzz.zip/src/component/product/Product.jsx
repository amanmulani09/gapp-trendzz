import React from 'react'
import Header from '../header/Header'

const Product = () => {
  return (
    <div>
      <Header />
    </div>
  )
}

export default Product