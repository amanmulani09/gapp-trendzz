import React from 'react'
import { Link } from 'react-router-dom'
import svg from '../assets/signup.svg'
import './signup.css'
import {
  MDBContainer,
  MDBInput,
  MDBCheckbox,
  MDBBtn,
  MDBIcon
}
  from 'mdb-react-ui-kit';




const Signup = () => {
  return (
    <div>

      <div className='signupForm'>
        <nav>

          <span className='logo'>GAPP-<span className='trendz'>Trendzz</span></span>


          <div className="leftLinks">

            <Link to="/" className="link left">Home</Link>
            <Link to="/product" className="link left" >Product</Link>

          </div>

          <Link to="/login" className="loginBtn link">log-in</Link>

        </nav>
        <div className="signup">
          <div className="asideLoginFrom">

            <img src={svg} alt="" className="loginsvgsignup" />
          </div>
          <div className="mainloginsignupFrom">
            <h2 >Sign up</h2>
            <MDBContainer className="p-10 my-4 d-flex flex-column w-60 loginbox" >

              <MDBInput wrapperClass='mb-4' label='Email address' id='form1' type='email' />
              <MDBInput wrapperClass='mb-4' label='Password' id='form2' type='password' />



              <MDBBtn className="mb-8 loginSubmitBtn">Sign in</MDBBtn>

              <div className="text-center">
                <p>Already have an account? <Link to="/login">log-in</Link></p>

              </div>

            </MDBContainer>
          </div>



        </div>

      </div>
    </div>
  )
}

export default Signup