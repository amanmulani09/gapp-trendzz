import React from 'react'
import { Link } from 'react-router-dom'
import './Login.css'
import {
  MDBContainer,
  MDBInput,
  MDBCheckbox,
  MDBBtn,
  MDBIcon
}
  from 'mdb-react-ui-kit';
import svg from '../assets/login1.svg'
const login = () => {
  return (
    <div>
      <nav>

        <span className='logo'>GAPP-<span className='trendz'>Trendzz</span></span>

        <div className="leftLinks">

          <Link to="/" className="link left">Home</Link>
          <Link to="/product" className="link left" >Product</Link>
        </div>
        <Link to="/signup" className="signupBtn link">Sign-up</Link>
      </nav>
      <div className="loginForm">
        <div className="asideLoginFrom">
          <img src={svg} alt="" className="loginsvg" />
        </div>


        <div className="mainloginFrom">
          <h2 className='wb'>Welcome Back </h2>
          <MDBContainer className="p-10 my-4 d-flex flex-column w-60 loginbox" >

            <MDBInput wrapperClass='mb-4' label='Email address' id='form1' type='email' />
            <MDBInput wrapperClass='mb-4' label='Password' id='form2' type='password' />

            <div className="d-flex justify-content-between mx-3 mb-4">
              <MDBCheckbox name='flexCheck' value='' id='flexCheckDefault' label='Remember me' />
            
            </div>

            <MDBBtn className="mb-8 loginSubmitBtn">Sign in</MDBBtn>

            <div className="text-center">
              <p>Not a member? <Link to="/signup">Register</Link></p>

            </div>

          </MDBContainer>
        </div>



      </div>
    </div>
  )
}

export default login