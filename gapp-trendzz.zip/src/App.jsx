import './App.css'
import RouterComponent from './router/RouterComponent'
import 'bootstrap/dist/css/bootstrap.min.css'
function App() {
 
  return (
    <div className="App">
        <RouterComponent />
    </div>
  )
}

export default App
